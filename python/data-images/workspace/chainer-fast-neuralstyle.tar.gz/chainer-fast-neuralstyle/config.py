# -*- coding:utf-8 -*-
#!/usr/bin/env python

# 配置文件
server = {
	'host': ['ftester.chinacloudapp.cn:4730'],
	'queue': 'test1'
}
